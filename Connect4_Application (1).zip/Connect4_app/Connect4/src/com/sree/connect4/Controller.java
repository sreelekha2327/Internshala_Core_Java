package com.sree.connect4;

import com.sun.org.apache.regexp.internal.RE;
import javafx.animation.TranslateTransition;
import javafx.application.Platform;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.geometry.Point2D;
import javafx.scene.control.*;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.Pane;
import javafx.scene.layout.VBox;
import javafx.scene.paint.Color;
import javafx.scene.shape.Circle;
import javafx.scene.shape.Rectangle;
import javafx.scene.shape.Shape;
import javafx.util.Duration;

import java.net.URL;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
import java.util.ResourceBundle;
import java.util.stream.Collectors;
import java.util.stream.IntStream;

public class Controller implements Initializable {
	private static final int ROWS = 6, COLUMNS = 7, CIRCLE_DIAMETER = 80;
	private static final String discColor1 = "#FF0000", discColour2 = "#0000FF";
	private static String PLAYER1 = "Player One", PLAYER2 = "Player Two";
	private boolean isPlayerOneTurn = true;
	private Disc[][] insertedDiscArray = new Disc[ROWS][COLUMNS];
	private boolean isAllowedtoInsert = true;



	@FXML
	public GridPane rootContainer;
	@FXML
	public Pane menuContainer;
	@FXML
	public Pane discContainer;
	@FXML
	public VBox playContainer;
	@FXML
	public Label playerLabel;
	@FXML
	public TextField playerOneTextField, playerTwoTextField;
	@FXML
	public Button setNamesButton;


	@Override
	public void initialize(URL location, ResourceBundle resources) {

	}

	public void createBackground() {
		Shape rectangleWithHoles=createGameStructuralGrid();
	    rootContainer.add(rectangleWithHoles, 0,1);

	    List<Rectangle> rectangleList = createClickableColumns();
	    for(Rectangle rectangle : rectangleList) {
		    rootContainer.add(rectangle, 0, 1);
	    }


	    setNamesButton.setOnAction(event -> {
	    	PLAYER1 = playerOneTextField.getText();
	    	PLAYER2 = playerTwoTextField.getText();
	    	playerLabel.setText(isPlayerOneTurn? PLAYER1 : PLAYER2);
	    });
	}

	private Shape createGameStructuralGrid(){
		Shape rectangleWithHoles = new Rectangle((COLUMNS+1) * CIRCLE_DIAMETER, (ROWS+1) * CIRCLE_DIAMETER);
		for(int row=0; row<ROWS;row++) {
			for (int col=0; col < COLUMNS; col++) {
				Circle circle = new Circle();
				circle.setRadius(CIRCLE_DIAMETER / 2);
				circle.setCenterX(CIRCLE_DIAMETER / 2);
				circle.setCenterY(CIRCLE_DIAMETER / 2);
				circle.setSmooth(true);
				circle.setTranslateX(col*(CIRCLE_DIAMETER+5)+CIRCLE_DIAMETER/4);
				circle.setTranslateY(row*(CIRCLE_DIAMETER+5)+CIRCLE_DIAMETER/4);
				rectangleWithHoles = Shape.subtract(rectangleWithHoles, circle);
			}
		}
		rectangleWithHoles.setFill(Color.WHITE);
		return rectangleWithHoles;
	}
	private List<Rectangle> createClickableColumns(){
		List<Rectangle> rectangleList = new ArrayList();
		for(int col=0; col<COLUMNS; col++) {
			Rectangle rect = new Rectangle(CIRCLE_DIAMETER, CIRCLE_DIAMETER * (ROWS + 1));
			rect.setFill(Color.TRANSPARENT);
			rect.setTranslateX(col*(CIRCLE_DIAMETER+5)+CIRCLE_DIAMETER / 4);
			rect.setOnMouseEntered(event -> rect.setFill(Color.valueOf("#eeeeee26")));
			rect.setOnMouseExited(event -> rect.setFill(Color.TRANSPARENT));
			final int column=col;
			rect.setOnMouseClicked(event -> {
				if(isAllowedtoInsert){
					isAllowedtoInsert=false;
				    insertDisc(new Disc(isPlayerOneTurn), column);
			}});
			rectangleList.add(rect);
		}
		return rectangleList;
	}
	private void insertDisc(Disc disc, int column){
		for(int i = (ROWS-1); i>=0; i--){
			if(insertedDiscArray[i][column]==null){
				insertedDiscArray[i][column] = disc;
				discContainer.getChildren().add(disc);
				disc.setTranslateX(column*(CIRCLE_DIAMETER+5)+CIRCLE_DIAMETER/4);
				TranslateTransition tt = new TranslateTransition(Duration.seconds(0.5),disc);
				tt.setToY(i*(CIRCLE_DIAMETER+5)+CIRCLE_DIAMETER/4);
				int currentRow = i;
				tt.setOnFinished(event ->{
					if(gameEnded(currentRow, column)){
						gameOver();
						return;
					}
					isPlayerOneTurn=!isPlayerOneTurn;
					playerLabel.setText(isPlayerOneTurn? PLAYER1 : PLAYER2);
					isAllowedtoInsert=true;
				});
				tt.play();
				break;
			}
		}



	}

	private void gameOver() {
		String winner = isPlayerOneTurn? PLAYER1:PLAYER2;
		System.out.println("Winner is " + winner);
		Alert d = new Alert(Alert.AlertType.INFORMATION);
		d.setTitle("Connect Four");
		d.setHeaderText("Winner is " + winner);
		d.setContentText("Want to play again?");
		ButtonType yes = new ButtonType("Yes");
		ButtonType no = new ButtonType("No, Exit");
		d.getButtonTypes().addAll(yes,no);
		Platform.runLater(()-> {
			Optional<ButtonType> action = d.showAndWait();
			if(action.isPresent() && action.get()== yes){
				resetgame();
			}else{
				Platform.exit();
				System.exit(0);
			}
		});


	}

	public void resetgame() {
		discContainer.getChildren().clear();
		for(int i=0; i<ROWS;i++){
			for(int j=0; j<COLUMNS;j++){
				insertedDiscArray[i][j]= null;
			}
		}
		playerOneTextField.clear();
		playerTwoTextField.clear();
		isPlayerOneTurn = true; //Let Player1 start the game
		PLAYER1 = "Player One";
		PLAYER2 = "Player Two";
		playerLabel.setText(isPlayerOneTurn? "Player One":"Player Two");
		createBackground();
	}

	private boolean gameEnded(int row, int col) {
		int maxrow=(row+3>ROWS-1)? ROWS-1 : row+3 ;
		int mincol=(col-3<0)? 0 : col-3;
		int maxcol=(col+3>COLUMNS-1)? COLUMNS-1 : col+3;
		//acute Diagonal Points
        List<Point2D> adp = new ArrayList<Point2D>();
		int j=col-3;
		for(int i=row+3; i>=row-3; i--){
			if(i>=0 && j>=0 && i<ROWS && j<COLUMNS){
				adp.add(new Point2D(i,j));
			}
			j++;
		}
		//obtuse Diagonal Points
		List<Point2D> odp = new ArrayList<Point2D>();
		j=col-3;
		for(int i=row-3; i<ROWS; i++){
			if(i>=0 && j>=0 && i<ROWS && j<COLUMNS){
				odp.add(new Point2D(i,j));
			}
			j++;
		}



		List<Point2D> verticalPoints = IntStream.rangeClosed(row,maxrow).mapToObj(r-> new Point2D(r,col)).collect(Collectors.toList());
		List<Point2D> horizontalPoints = IntStream.rangeClosed(mincol,maxcol).mapToObj(c-> new Point2D(row,c)).collect(Collectors.toList());


		boolean isEnded = checkCombinations(verticalPoints) || checkCombinations(horizontalPoints)||checkCombinations(adp)||checkCombinations(odp);
		return isEnded;
    }

	private boolean checkCombinations(List<Point2D> points) {
		int chain = 0;
		for(Point2D point : points){
			int rowIndexForArray = (int) point.getX();
			int colIndexForArray = (int) point.getY();
			Disc disc = insertedDiscArray[rowIndexForArray][colIndexForArray];
			if(disc != null && disc.isPlayerOneMove==isPlayerOneTurn){
				chain++;
				if(chain==4){
					return true;
				}
			}else{
				chain=0;
			}
		}
		return false;
	}

	private static class Disc extends Circle{
		private final boolean isPlayerOneMove;
		public Disc(boolean isPlayerOneMove){
			this.isPlayerOneMove=isPlayerOneMove;
			setRadius(CIRCLE_DIAMETER/2);
			setFill(isPlayerOneMove? Color.valueOf(discColor1):Color.valueOf(discColour2));
			setCenterX(CIRCLE_DIAMETER/2);
			setCenterY(CIRCLE_DIAMETER/2);

		}
	}
}
