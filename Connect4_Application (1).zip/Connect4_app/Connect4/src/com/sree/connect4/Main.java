package com.sree.connect4;

import javafx.application.Application;
import javafx.application.Platform;
import javafx.fxml.FXMLLoader;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.control.Menu;
import javafx.scene.control.MenuBar;
import javafx.scene.control.MenuItem;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.Pane;
import javafx.stage.Stage;

import java.awt.*;

public class Main extends Application {
    private Controller controller;
    public static void main(String[] args) {
        launch(args);
    }

    @Override
    public void init() throws Exception {
        super.init();
    }

    @Override
    public void start(Stage primaryStage) throws Exception {
        FXMLLoader loader = new FXMLLoader(getClass().getResource("game.fxml"));
        GridPane rootContainer = loader.load();
        controller = loader.getController();
        controller.createBackground();

        MenuBar mb = createmenu();
        mb.prefWidthProperty().bind(primaryStage.widthProperty());

        Pane menuPane = (Pane) rootContainer.getChildren().get(0);
        mb.prefHeightProperty().bind(menuPane.heightProperty());
        menuPane.getChildren().add(mb);

        Scene scene = new Scene(rootContainer);
        primaryStage.setScene(scene);
        primaryStage.setTitle("Connect4");
        primaryStage.setResizable(false);
        primaryStage.show();

    }

    @Override
    public void stop() throws Exception {
        super.stop();
    }

    public MenuBar createmenu(){
        Menu filemenu = new Menu("File");
        MenuItem newGame = new MenuItem("New Game");
        newGame.setOnAction(event -> controller.resetgame());

        MenuItem resetGame = new MenuItem("Reset Game");
        resetGame.setOnAction(event ->controller.resetgame());


        SeparatorMenuItem sp = new SeparatorMenuItem();
        MenuItem exitGame = new MenuItem("Exit Game");
        exitGame.setOnAction(event -> exitGame());
        
        filemenu.getItems().addAll(newGame, resetGame, sp,exitGame);


        Menu helpmenu = new Menu("Help");
        MenuItem aboutGame = new MenuItem("About Game");
        aboutGame.setOnAction(event -> aboutConnect4());

        SeparatorMenuItem sp1 = new SeparatorMenuItem();
        MenuItem aboutMe = new MenuItem("About Me");
        aboutMe.setOnAction(event -> aboutMe());

        helpmenu.getItems().addAll(aboutGame,sp1,aboutMe);

        MenuBar mBar = new MenuBar();
        mBar.getMenus().addAll(filemenu, helpmenu);
        return mBar;

    }

    private void aboutMe() {
        Alert ad = new Alert(Alert.AlertType.INFORMATION);
        ad.setTitle("About Developer");
        ad.setHeaderText("Sreelekha");
        ad.setContentText("I love coding.....................");
        ad.show();
    }

    private void aboutConnect4() {
        Alert ad = new Alert(Alert.AlertType.INFORMATION);
        ad.setTitle("About Connect Four");
        ad.setHeaderText("How To Play?");
        ad.setContentText("Connect Four is a two-player connection game in which the players first choose a color and then take turns dropping colored discs" +
                "from the top into a seven-column, six-row vertically suspended grid. The pieces fall straight down, occupying the next available space" +
                "within the column. The objective of the game is to be the first to form a horizontal, vertical, or diagonal line of four of one's own discs." +
                "Connect Four is a solved game. The first player can always win by playing the right moves.");
        ad.show();
    }

    private void exitGame() {
        Platform.exit();
        System.exit(0);
    }



}



